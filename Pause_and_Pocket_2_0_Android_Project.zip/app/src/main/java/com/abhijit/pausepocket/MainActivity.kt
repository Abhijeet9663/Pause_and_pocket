package com.abhijit.pausepocket

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("pause_pocket", Context.MODE_PRIVATE) }
    private val ledgerPrefs by lazy { getSharedPreferences("ledger", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var currentTab = "home"
    private val bg = Color.rgb(13, 15, 23)
    private val panel = Color.rgb(29, 31, 42)
    private val panel2 = Color.rgb(39, 41, 52)
    private val green = Color.rgb(157, 202, 103)
    private val pink = Color.rgb(238, 165, 192)
    private val cream = Color.rgb(246, 238, 220)
    private val muted = Color.rgb(174, 174, 184)
    private val apps = linkedMapOf(
        "Google Pay" to "com.google.android.apps.nbu.paisa.user",
        "PhonePe" to "com.phonepe.app", "Paytm" to "net.one97.paytm",
        "BHIM" to "in.org.npci.upiapp", "Navi" to "com.naviapp"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildShell(); render()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 22): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun gradient(a: Int, b: Int, radius: Int = 24) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a,b)).apply { cornerRadius = dp(radius).toFloat() }
    private fun txt(s: String, size: Float = 15f, color: Int = cream, bold: Boolean = false): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(3), 0, dp(3))
    }
    private fun gap(h: Int = 12) { body.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(16),dp(18),dp(16)); background=shape(panel,22) }
    private fun addCard(v: View) { body.addView(v, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(12) }) }
    private fun action(s: String, primary: Boolean = false, onClick: () -> Unit): TextView = TextView(this).apply {
        text=s; textSize=15f; gravity=Gravity.CENTER; setTextColor(if(primary) Color.rgb(22,32,18) else cream); setTypeface(typeface,Typeface.BOLD)
        setPadding(dp(16),dp(13),dp(16),dp(13)); background=shape(if(primary) green else panel2,18); setOnClickListener { onClick() }
    }
    private fun field(hintText: String, numeric: Boolean = false): EditText = EditText(this).apply {
        hint=hintText; setHintTextColor(muted); setTextColor(cream); textSize=15f; setSingleLine(true)
        if(numeric) inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(dp(13),dp(8),dp(13),dp(8)); background=shape(panel2,14)
    }
    private fun buildShell() {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18),dp(12),dp(18),0) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(5),0,dp(10)) }
        top.addView(txt("🌿  Pause & Pocket",22f,cream,true),LinearLayout.LayoutParams(0,-2,1f))
        top.addView(txt("🌙",25f,pink))
        root.addView(top)
        val scroll=ScrollView(this).apply { isFillViewport=true; clipToPadding=false }
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,dp(4),0,dp(24)) }
        scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(dp(5),dp(8),dp(5),dp(12)); background=shape(panel,22) }
        listOf("home" to "⌂\nHome", "money" to "▤\nActivity", "insights" to "◔\nInsights", "gate" to "♧\nGuard").forEach { (key,label) ->
            val item=TextView(this).apply { text=label; gravity=Gravity.CENTER; textSize=12f; setTextColor(if(currentTab==key) green else muted); setPadding(dp(8),dp(3),dp(8),dp(3)); setOnClickListener { currentTab=key; buildShell(); render() } }
            nav.addView(item,LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav); setContentView(root)
    }
    private fun render() { body.removeAllViews(); when(currentTab){"money"->moneyScreen();"insights"->insightsScreen();"gate"->gateScreen();else->homeScreen()} }
    private fun entries(): JSONArray = try { JSONArray(ledgerPrefs.getString("entries","[]")) } catch(_:Exception){JSONArray()}
    private fun save(a:JSONArray){ledgerPrefs.edit().putString("entries",a.toString()).apply()}
    private fun totals():Pair<Double,Double>{val a=entries();var i=0.0;var e=0.0;for(n in 0 until a.length()){val o=a.getJSONObject(n);if(o.optString("type")=="income")i+=o.optDouble("amount") else e+=o.optDouble("amount")};return i to e}
    private fun money(v:Double)="₹"+String.format(Locale("en","IN"),"%,.0f",v)

    private fun homeScreen(){
        val (inc,exp)=totals(); val bal=inc-exp; val budget=prefs.getFloat("budget",0f).toDouble()
        body.addView(txt("TUESDAY NIGHT · TAKE A BREATH",11f,green,true)); gap(4)
        body.addView(txt("A little pause today\ncan save a lot tomorrow.",25f,cream,true)); gap(12)
        val art=NightMeadowView(this).apply { background=shape(panel,24) }
        body.addView(art,LinearLayout.LayoutParams(-1,dp(205)).apply{bottomMargin=dp(12)})
        val balance=card(); balance.background=gradient(Color.rgb(51,65,48),Color.rgb(34,39,48),24)
        balance.addView(txt("CURRENT BALANCE",11f,cream,true)); balance.addView(txt(money(bal),34f,cream,true)); balance.addView(txt("Your recorded money · income minus expenses",12f,muted)); addCard(balance)
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val ci=card().apply { addView(txt("INCOME",11f,green,true));addView(txt("↗ ${money(inc)}",19f,cream,true)) }
        val ce=card().apply { addView(txt("EXPENSES",11f,pink,true));addView(txt("↘ ${money(exp)}",19f,cream,true)) }
        row.addView(ci,LinearLayout.LayoutParams(0,-2,1f).apply{rightMargin=dp(6)});row.addView(ce,LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(6)});addCard(row)
        val budgetCard=card();budgetCard.addView(txt("MONTHLY BUDGET",12f,green,true));budgetCard.addView(txt(if(budget>0) "${money(exp)} of ${money(budget)} spent" else "Give your month a gentle limit",18f,cream,true))
        if(budget>0){val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=((exp/budget)*100).toInt().coerceIn(0,100);progressTintList=android.content.res.ColorStateList.valueOf(green);progressBackgroundTintList=android.content.res.ColorStateList.valueOf(panel2)};budgetCard.addView(bar,LinearLayout.LayoutParams(-1,dp(8)).apply{topMargin=dp(10)})}
        budgetCard.addView(action("Set monthly budget",false){budgetDialog()});addCard(budgetCard)
        body.addView(txt("QUICK ACTIONS",12f,green,true));gap(6)
        body.addView(action("＋   Add income or expense",true){currentTab="money";render()});gap(8)
        body.addView(action("☾   Spending guard settings",false){currentTab="gate";render()});gap(12)
        body.addView(txt("Your records stay on this phone. They are not connected to your bank.",12f,muted))
    }
    private fun insightsScreen(){
        val (inc,exp)=totals()
        body.addView(txt("A little perspective",26f,cream,true))
        body.addView(txt("Your money, seen gently — no judgement.",14f,muted));gap(14)
        val summary=card();summary.addView(txt("TOTAL SPENDING",11f,pink,true));summary.addView(txt(money(exp),34f,cream,true));summary.addView(txt("Recorded expenses on this device",12f,muted));addCard(summary)
        val a=entries();val cats=linkedMapOf<String,Double>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);if(o.optString("type")!="income"){val k=o.optString("category","Other");cats[k]=(cats[k]?:0.0)+o.optDouble("amount")}}
        val chart=card();chart.addView(txt("WHERE IT GOES",12f,green,true));gap(8)
        if(cats.isEmpty()){chart.addView(txt("Your spending picture will appear after your first expense.",14f,muted))}else{
            val max=cats.values.maxOrNull()?:1.0
            cats.entries.sortedByDescending{it.value}.forEach{(name,value)->
                val line=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                line.addView(txt(name,13f,cream),LinearLayout.LayoutParams(0,-2,1f));line.addView(txt(money(value),13f,pink,true))
                chart.addView(line);val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=((value/max)*100).toInt();progressTintList=android.content.res.ColorStateList.valueOf(if(name.hashCode()%2==0)green else pink);progressBackgroundTintList=android.content.res.ColorStateList.valueOf(panel2)}
                chart.addView(bar,LinearLayout.LayoutParams(-1,dp(7)).apply{topMargin=dp(4);bottomMargin=dp(10)})
            }
        };addCard(chart)
        val net=card();net.addView(txt("INCOME VS EXPENSES",12f,green,true));net.addView(txt("Income  ${money(inc)}",16f,cream,true));net.addView(txt("Expenses  ${money(exp)}",16f,pink,true));net.addView(txt("Balance  ${money(inc-exp)}",18f,green,true));addCard(net)
        body.addView(txt("Insights use only the transactions you enter here. They are not bank data.",12f,muted))
    }

    private fun budgetDialog(){val e=field("Monthly budget in ₹",true);e.setText(if(prefs.getFloat("budget",0f)>0)prefs.getFloat("budget",0f).toString() else "");android.app.AlertDialog.Builder(this).setTitle("A gentle monthly limit").setView(e).setPositiveButton("Save"){_,_->e.text.toString().toFloatOrNull()?.let{prefs.edit().putFloat("budget",it).apply();render()}}.setNegativeButton("Cancel",null).show()}
    private fun gateScreen(){
        body.addView(txt("Spending guard",26f,cream,true));body.addView(txt("A little moonlit pause before you open a payment app.",14f,muted));gap(12)
        val c=card();c.addView(txt("🌙  YOUR PAUSE MOMENT",12f,pink,true));c.addView(txt("Think. Pause. Spend wiser.",21f,cream,true));c.addView(txt("When an enabled payment app opens, the guard asks you to type your exact confirmation phrase.",13f,muted));gap(8);c.addView(action("Open Android accessibility settings",true){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))});c.addView(txt(if(isServiceEnabled())"● Guard service appears enabled" else "○ Guard service is not enabled",13f,if(isServiceEnabled())green else pink));addCard(c)
        body.addView(txt("PAYMENT APPS TO WATCH",12f,green,true));gap(4)
        apps.forEach{(name,pkg)->val cb=CheckBox(this).apply{text=name;setTextColor(cream);buttonTintList=android.content.res.ColorStateList.valueOf(green);isChecked=prefs.getBoolean("app_$pkg",true);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("app_$pkg",v).apply()}};body.addView(cb)}
        gap(8);val other=field("Other app package name (optional)");other.setText(prefs.getString("other_package",""));body.addView(other);gap(6);body.addView(action("Save other app",true){prefs.edit().putString("other_package",other.text.toString().trim()).apply();Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()});gap(12)
        val privacy=card();privacy.addView(txt("A NOTE ABOUT PRIVACY",11f,pink,true));privacy.addView(txt("The service watches selected app-window changes. It does not read screen text, UPI PINs, OTPs, messages or payment details. This is a reminder layer, not an unbreakable payment lock.",12f,muted));addCard(privacy)
    }
    private fun isServiceEnabled():Boolean{val am=getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager;return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==packageName&&it.resolveInfo.serviceInfo.name==SpendingGateService::class.java.name}}
    private fun moneyScreen(){
        body.addView(txt("Your little ledger",26f,cream,true));body.addView(txt("Every rupee has a story. Keep track of yours.",14f,muted));gap(12)
        val c=card();c.addView(txt("NEW TRANSACTION",12f,green,true));val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Expense","Income"))};val amount=field("Amount in ₹",true);val note=field("What was it for?");val cat=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Food","Travel","Books & learning","Shopping","Entertainment","Bills","Health","Other"))};c.addView(txt("Type",12f,muted));c.addView(type);c.addView(txt("Amount",12f,muted));c.addView(amount);c.addView(txt("Category",12f,muted));c.addView(cat);c.addView(txt("Note",12f,muted));c.addView(note);gap(8);c.addView(action("Save transaction",true){val v=amount.text.toString().toDoubleOrNull();if(v==null||v<=0){Toast.makeText(this,"Enter a valid amount",Toast.LENGTH_SHORT).show();return@action};val a=entries();a.put(JSONObject().put("type",if(type.selectedItemPosition==1)"income" else "expense").put("amount",v).put("category",cat.selectedItem.toString()).put("note",note.text.toString()).put("date",SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())));save(a);Toast.makeText(this,"Saved on this phone",Toast.LENGTH_SHORT).show();render()});addCard(c)
        body.addView(txt("RECENT TRANSACTIONS",12f,pink,true));val a=entries();if(a.length()==0){val empty=card();empty.addView(txt("🌸  Nothing here yet",18f,cream,true));empty.addView(txt("Your first entry will appear here.",13f,muted));addCard(empty)}
        for(i in a.length()-1 downTo 0){val o=a.getJSONObject(i);val income=o.optString("type")=="income";val item=card();item.addView(txt((if(income)"↗  " else "↘  ")+o.optString("category"),16f,cream,true));item.addView(txt((if(income)"+" else "−")+money(o.optDouble("amount"))+"     ·     "+o.optString("date"),15f,if(income)green else pink,true));if(o.optString("note").isNotBlank())item.addView(txt(o.optString("note"),12f,muted));addCard(item)}
        body.addView(action("Export transactions (CSV text)",false){exportCsv()})
    }
    private fun exportCsv(){val a=entries();val sb=StringBuilder("type,amount,category,note,date\n");for(i in 0 until a.length()){val o=a.getJSONObject(i);val vals=listOf(o.optString("type"),o.optString("amount"),o.optString("category"),o.optString("note"),o.optString("date"));sb.append(vals.joinToString(","){"\"${it.replace("\"","\"\"")}\""}).append("\n")};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,sb.toString())},"Share CSV text"))}
}
