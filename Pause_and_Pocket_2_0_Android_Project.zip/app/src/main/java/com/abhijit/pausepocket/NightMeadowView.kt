package com.abhijit.pausepocket

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.sin

/** Original, lightweight Canvas illustration inspired by the user's moonlit meadow painting. */
class NightMeadowView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun color(c: Int) { p.color = c; p.shader = null; p.style = Paint.Style.FILL }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w=width.toFloat(); val h=height.toFloat()
        p.shader=android.graphics.LinearGradient(0f,0f,w,h,Color.rgb(18,22,36),Color.rgb(24,39,35),Shader.TileMode.CLAMP)
        canvas.drawRoundRect(0f,0f,w,h,dp(22),dp(22),p);p.shader=null
        // Moon and soft halo
        p.shader=RadialGradient(w*.79f,h*.25f,dp(43),intArrayOf(0x66fff1cf,0x22fff1cf,0x00fff1cf),null,Shader.TileMode.CLAMP)
        canvas.drawCircle(w*.79f,h*.25f,dp(43),p);p.shader=null
        color(0xffffedc9);canvas.drawCircle(w*.79f,h*.25f,dp(22),p)
        color(0xffe6d9bc);for(i in 0..5) canvas.drawCircle(w*.79f+sin(i*2.0).toFloat()*dp(7),h*.25f+sin(i*3.1).toFloat()*dp(6),dp(2),p)
        // Rolling meadow
        color(0xff344b37);val hill=Path().apply{moveTo(0f,h*.78f);cubicTo(w*.22f,h*.62f,w*.56f,h*.82f,w,h*.66f);lineTo(w,h);lineTo(0f,h);close()};canvas.drawPath(hill,p)
        color(0xff526e42);val hill2=Path().apply{moveTo(0f,h*.87f);cubicTo(w*.3f,h*.73f,w*.7f,h*.9f,w,h*.79f);lineTo(w,h);lineTo(0f,h);close()};canvas.drawPath(hill2,p)
        // Cherry tree trunk and branches
        p.color=0xff624532;p.strokeWidth=dp(8);p.strokeCap=Paint.Cap.ROUND;canvas.drawLine(w*.18f,h*.83f,w*.25f,h*.28f,p)
        p.strokeWidth=dp(4);canvas.drawLine(w*.25f,h*.47f,w*.11f,h*.28f,p);canvas.drawLine(w*.24f,h*.42f,w*.4f,h*.22f,p);canvas.drawLine(w*.23f,h*.34f,w*.17f,h*.17f,p);canvas.drawLine(w*.25f,h*.29f,w*.33f,h*.12f,p)
        // Blossom canopy clusters
        val blossom=0xffffc6d7;val pale=0xffffdce5
        val clusters=listOf(.12f to .22f,.23f to .16f,.34f to .19f,.15f to .34f,.31f to .31f,.42f to .28f)
        clusters.forEachIndexed{idx,pair->
            val cx=w*pair.first;val cy=h*pair.second
            for(j in 0..10){val dx=((j*17+idx*11)%31-15)*dp(1);val dy=((j*13+idx*7)%25-12)*dp(1);color(if(j%3==0)pale else blossom);canvas.drawCircle(cx+dx,cy+dy,dp(if(j%4==0)4 else 3),p)}
        }
        // A few falling petals
        for(i in 0..15){val x=w*(.39f+(i%5)*.075f);val y=h*(.39f+(i/5)*.12f)+sin(i.toDouble()).toFloat()*dp(4);color(if(i%2==0)pale else blossom);canvas.save();canvas.rotate((i*19%50).toFloat(),x,y);canvas.drawOval(x-dp(2),y-dp(4),x+dp(2),y+dp(4),p);canvas.restore()}
        // Two small silhouettes walking together
        drawPerson(canvas,w*.61f,h*.73f,dp(1f),0xff151a20.toInt())
        drawPerson(canvas,w*.69f,h*.75f,dp(.82f),0xff151a20.toInt())
        // Tiny meadow flowers
        for(i in 0..8){val x=w*(.08f+i*.105f);val y=h*(.91f+(i%2)*.025f);color(0xffffd7e1);canvas.drawCircle(x,y,dp(2.5f),p);color(0xffffdca0);canvas.drawCircle(x,y,dp(1f),p)}
    }
    private fun drawPerson(c:Canvas,x:Float,y:Float,s:Float,col:Int){
        color(col);c.drawCircle(x,y-dp(18f)*s,dp(4f)*s,p);p.strokeWidth=dp(3f)*s;p.strokeCap=Paint.Cap.ROUND
        c.drawLine(x,y-dp(13f)*s,x,y,p);c.drawLine(x,y-dp(9f)*s,x-dp(6f)*s,y-dp(3f)*s,p);c.drawLine(x,y-dp(9f)*s,x+dp(6f)*s,y-dp(4f)*s,p);c.drawLine(x,y,x-dp(5f)*s,y+dp(9f)*s,p);c.drawLine(x,y,x+dp(6f)*s,y+dp(8f)*s,p)
    }
    private fun dp(v:Float)=v*resources.displayMetrics.density
}
