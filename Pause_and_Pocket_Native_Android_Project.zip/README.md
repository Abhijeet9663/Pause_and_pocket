# Pause & Pocket — Native Android project

This is the native Kotlin/Android source project for your personal APK. The ZIP is source code; it is not itself an APK. A GitHub Actions workflow can compile it in the cloud, so you do not need a computer or Android Studio.

## Build the APK using only your phone

### A. Create a GitHub repository
1. Open https://github.com/new in your phone browser.
2. Repository name: `pause-and-pocket`.
3. Choose Private (recommended) or Public, then create it.

### B. Upload this project ZIP
1. Open the new repository.
2. Tap **Add file → Upload files**.
3. Upload this downloaded file itself, named exactly `Pause_and_Pocket_Native_Android_Project.zip`.
4. Commit the upload to the `main` branch.

### C. Add the cloud-build workflow
1. In the repository, tap **Add file → Create new file**.
2. For the filename, enter exactly `.github/workflows/build.yml`.
3. Open the `GITHUB_BOOTSTRAP_WORKFLOW.txt` file from this project ZIP, copy all its contents, and paste them into the GitHub editor.
4. Commit the new file to `main`.

### D. Download your APK
1. Open the repository's **Actions** tab.
2. Open **Build Pause & Pocket APK**. If it has not started, choose **Run workflow**.
3. Wait for the run to finish with a green check.
4. Open the completed run, scroll to **Artifacts**, and download `pause-pocket-debug-apk`.
5. Extract that downloaded artifact ZIP. Tap `app-debug.apk` to install it.
6. If Android asks, allow your browser or file manager to install unknown apps.

## Enable the spending gate
1. Open Pause & Pocket → Spending gate.
2. Tap **Enable / manage Android accessibility permission**.
3. In Android Settings → Accessibility → Installed apps / Downloaded apps, select **Pause & Pocket spending gate** and enable it.
4. Return to the app. Select the payment apps to monitor.

## What this version does
- Monitors selected app launches using an Android AccessibilityService.
- Displays a confirmation overlay with the exact phrase: `Yeah I want this it is important`.
- Offers a cancel action that sends Android Back.
- Tracks income and expenses locally, shows a calculated balance, supports a monthly budget and CSV text export.

## Important limitations and safety
- The service listens for app-window changes only. It has `canRetrieveWindowContent=false` and does not inspect screen contents, OTPs, UPI PINs, messages, or payment details.
- This is a reminder layer, not an unbreakable payment lock. Android allows users to disable accessibility services or reach payment apps through other routes.
- Package names can differ across app versions/devices. The listed Navi package may need verification on your phone. "Other" requires an Android package name, not just its display name.
- The overlay does not know whether a payment actually succeeded. Add the real expense manually after paying.
- This is an unsigned debug APK for personal testing, not a Play Store release.
- Data is stored locally in the app. Export records before uninstalling or clearing app data.
- No bank account or UPI transaction history is connected.

## If the GitHub build fails
Open the failed Actions run and share the first red error section here. I can help correct the project/workflow.


Build configuration note: Java and Kotlin compilation targets are both set to JVM 17.
