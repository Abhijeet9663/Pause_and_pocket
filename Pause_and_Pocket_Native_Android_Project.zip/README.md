# Pause & Pocket 2.0 — Cherry Blossom Night

A painting-inspired visual redesign of the native Android app. The interface uses a midnight sky, moonlight, cherry blossoms, a green meadow and two tiny walking silhouettes. The hero illustration is drawn natively with Android Canvas, so it is part of the app rather than a downloaded image.

## What is included

- Home dashboard with current recorded balance, income, expenses and monthly budget.
- Native illustrated moonlit-meadow hero panel.
- Activity screen for adding income/expenses, reviewing transactions and exporting CSV text.
- Insights screen with category spending bars and income/expense totals.
- Spending Guard settings for Google Pay, PhonePe, Paytm, BHIM, Navi and an optional package name.
- Matching dark cherry-blossom styling for the spending confirmation overlay.
- Local-only transaction storage; no bank connection.

## Build the updated APK using your phone

1. Download the new `Pause_and_Pocket_Native_Android_Project.zip` from this chat.
2. Open your GitHub repository and delete the old `Pause_and_Pocket_Native_Android_Project.zip` file.
3. Upload this new ZIP to the repository root. Keep the exact filename `Pause_and_Pocket_Native_Android_Project.zip`.
4. Commit the upload to `main`. Your existing GitHub Actions workflow should start automatically.
5. Open **Actions**. Wait for the newest run to turn green.
6. Open the successful run, download the `pause-pocket-debug-apk` artifact, extract that artifact ZIP, and install `app-debug.apk`.

If the workflow file is missing, create `.github/workflows/build.yml` and paste the contents of `GITHUB_BOOTSTRAP_WORKFLOW.txt` from this archive.

## Important notes

- This ZIP contains Android source code, not a prebuilt APK. GitHub Actions must compile it.
- The source has not been compiled on this machine or tested on your phone. If GitHub reports a failure, share the first actual error lines from the failed build step.
- Before replacing the installed app, export your transactions. Android may require uninstalling the previous build if it was signed with a different debug key; uninstalling clears the app's local data.
- The spending gate is an accessibility-based reminder layer, not an unbreakable payment lock. It does not read screen contents, UPI PINs, OTPs, messages or payment details.
