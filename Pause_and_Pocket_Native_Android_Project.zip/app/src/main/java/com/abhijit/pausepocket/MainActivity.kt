package com.abhijit.pausepocket

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("pause_pocket", Context.MODE_PRIVATE) }
    private val ledgerPrefs by lazy { getSharedPreferences("ledger", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var currentTab = "home"
    private var entryType = "expense"

    private val apps = linkedMapOf(
        "Google Pay" to "com.google.android.apps.nbu.paisa.user",
        "PhonePe" to "com.phonepe.app",
        "Paytm" to "net.one97.paytm",
        "BHIM" to "in.org.npci.upiapp",
        "Navi" to "com.naviapp"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showShell()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 15f, color: Int = Color.rgb(25, 47, 41)): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, dp(5), 0, dp(5)) }
    private fun button(s: String, action: () -> Unit): Button =
        Button(this).apply { text = s; isAllCaps = false; setOnClickListener { action() } }
    private fun input(hint: String, numeric: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            textSize = 15f
            setSingleLine(true)
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
    private fun label(s: String) { body.addView(text(s, 13f, Color.DKGRAY)) }
    private fun gap(h: Int = 8) { body.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun showShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,247,243)); setPadding(dp(18), dp(12), dp(18), dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("pause ", 24f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        header.addView(text("& pocket", 24f, Color.rgb(23,107,85)).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(header)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("home" to "Overview", "gate" to "Spending gate", "money" to "My money").forEach { (key, title) ->
            nav.addView(button(title) { currentTab = key; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(24)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun render() {
        body.removeAllViews()
        when (currentTab) {
            "gate" -> gateScreen()
            "money" -> moneyScreen()
            else -> homeScreen()
        }
    }

    private fun readEntries(): JSONArray = try { JSONArray(ledgerPrefs.getString("entries", "[]")) } catch (_: Exception) { JSONArray() }
    private fun saveEntries(a: JSONArray) { ledgerPrefs.edit().putString("entries", a.toString()).apply() }
    private fun totals(): Pair<Double, Double> {
        val a = readEntries(); var income = 0.0; var expense = 0.0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("type") == "income") income += o.optDouble("amount") else expense += o.optDouble("amount")
        }
        return income to expense
    }
    private fun rupees(v: Double) = "₹" + String.format(Locale("en","IN"), "%,.2f", v)

    private fun homeScreen() {
        val (inc, exp) = totals()
        body.addView(text("YOUR MONEY, YOUR RULES", 12f, Color.GRAY))
        body.addView(text(rupees(inc-exp), 32f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        body.addView(text("Recorded balance · income minus expenses", 13f, Color.GRAY))
        gap(18)
        body.addView(text("Income: ${rupees(inc)}       Spending: ${rupees(exp)}", 16f))
        gap()
        val budget = prefs.getFloat("budget", 0f).toDouble()
        body.addView(text("Monthly budget: ${if (budget > 0) rupees(budget) else "Not set"}"))
        body.addView(button("Set monthly budget") {
            val e = input("Budget amount", true)
            android.app.AlertDialog.Builder(this).setTitle("Monthly budget").setView(e)
                .setPositiveButton("Save") { _, _ -> e.text.toString().toDoubleOrNull()?.let { prefs.edit().putFloat("budget", it.toFloat()).apply(); render() } }
                .setNegativeButton("Cancel", null).show()
        })
        gap(14)
        body.addView(text("Quick actions", 18f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        body.addView(button("Open spending gate settings") { currentTab = "gate"; render() })
        body.addView(button("Add income or expense") { currentTab = "money"; render() })
        body.addView(text("Your entries are stored locally on this phone. Nothing is sent to a bank or server.", 12f, Color.GRAY))
    }

    private fun gateScreen() {
        body.addView(text("Spending gate", 24f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        body.addView(text("When an enabled payment app opens, Pause & Pocket displays a confirmation overlay.", 14f, Color.DKGRAY))
        gap(8)
        body.addView(button("Enable / manage Android accessibility permission") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        val enabled = isServiceEnabled()
        body.addView(text(if (enabled) "● Spending gate service appears enabled" else "○ Spending gate service is not enabled", 14f, if (enabled) Color.rgb(23,107,85) else Color.rgb(170,80,55)))
        gap(8)
        body.addView(text("Payment apps to monitor", 18f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        apps.forEach { (name, pkg) ->
            val cb = CheckBox(this).apply {
                text = "$name  ($pkg)"
                isChecked = prefs.getBoolean("app_$pkg", true)
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("app_$pkg", checked).apply() }
            }
            body.addView(cb)
        }
        val other = input("Other app package name (optional)")
        other.setText(prefs.getString("other_package", ""))
        body.addView(other)
        body.addView(button("Save other app package") {
            prefs.edit().putString("other_package", other.text.toString().trim()).apply()
            Toast.makeText(this, "Saved. Reopen accessibility settings/service if needed.", Toast.LENGTH_LONG).show()
        })
        gap(10)
        body.addView(text("Privacy: the service listens only for app-window changes for the selected packages. It does not retrieve screen text or inspect UPI PINs, OTPs, messages or payment details.", 12f, Color.GRAY))
        body.addView(text("Android may allow bypasses (for example, disabling the service or using another route to a payment app). This is a reminder layer, not a secure payment lock.", 12f, Color.GRAY))
    }

    private fun isServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName && it.resolveInfo.serviceInfo.name == SpendingGateService::class.java.name }
    }

    private fun moneyScreen() {
        body.addView(text("Money manager", 24f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        val amount = input("Amount in ₹", true)
        val note = input("Description (e.g. lunch, book, pocket money)")
        val category = Spinner(this)
        val categories = listOf("Food", "Travel", "Books & learning", "Shopping", "Entertainment", "Bills", "Health", "Other")
        category.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Expense", "Income"))
        body.addView(type); label("Amount"); body.addView(amount); label("Category"); body.addView(category); label("Note"); body.addView(note)
        body.addView(button("Save entry") {
            val v = amount.text.toString().toDoubleOrNull()
            if (v == null || v <= 0) { Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show(); return@button }
            val a = readEntries()
            a.put(JSONObject().put("type", if (type.selectedItemPosition == 1) "income" else "expense")
                .put("amount", v).put("category", category.selectedItem.toString())
                .put("note", note.text.toString()).put("date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())))
            saveEntries(a); Toast.makeText(this, "Saved on this phone", Toast.LENGTH_SHORT).show(); render()
        })
        gap(18)
        body.addView(text("Recorded transactions", 18f).apply { setTypeface(null, android.graphics.Typeface.BOLD) })
        val a = readEntries()
        for (i in a.length()-1 downTo 0) {
            val o = a.getJSONObject(i)
            val sign = if (o.optString("type") == "income") "+" else "−"
            body.addView(text("$sign${rupees(o.optDouble("amount"))}  ·  ${o.optString("category")}\n${o.optString("note")}  ·  ${o.optString("date")}", 14f))
        }
        if (a.length() == 0) body.addView(text("No entries yet."))
        body.addView(button("Export transactions (CSV)") { exportCsv() })
    }

    private fun exportCsv() {
        val a = readEntries()
        val sb = StringBuilder("type,amount,category,note,date\n")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val vals = listOf(o.optString("type"), o.optString("amount"), o.optString("category"), o.optString("note"), o.optString("date"))
            sb.append(vals.joinToString(",") { "\"${it.replace("\"","\"\"")}\"" }).append("\n")
        }
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, sb.toString()) }
        startActivity(Intent.createChooser(intent, "Share CSV text; copy it into a .csv file"))
    }
}
