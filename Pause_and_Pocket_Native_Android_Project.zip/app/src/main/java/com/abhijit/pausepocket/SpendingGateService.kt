package com.abhijit.pausepocket

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SpendingGateService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: View? = null
    private var lastPackage = ""
    private var lastShownAt = 0L
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        updateTargets()
    }

    private fun updateTargets() {
        val p = getSharedPreferences("pause_pocket", Context.MODE_PRIVATE)
        val packages = mutableListOf<String>()
        val defaults = listOf(
            "com.google.android.apps.nbu.paisa.user", "com.phonepe.app",
            "net.one97.paytm", "in.org.npci.upiapp", "com.naviapp"
        )
        defaults.forEach { if (p.getBoolean("app_$it", true)) packages.add(it) }
        p.getString("other_package", "")?.trim()?.takeIf { it.isNotEmpty() }?.let { packages.add(it) }
        val info = serviceInfo
        info.packageNames = packages.distinct().toTypedArray()
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        updateTargets()
        val pkg = event.packageName?.toString() ?: return
        val targets = serviceInfo.packageNames?.toSet() ?: emptySet()
        if (pkg !in targets || pkg == packageName) return
        val now = System.currentTimeMillis()
        if (overlay != null || (pkg == lastPackage && now - lastShownAt < 2500)) return
        lastPackage = pkg
        lastShownAt = now
        handler.post { showGate(pkg) }
    }

    private fun showGate(target: String) {
        if (overlay != null) return
        val p = getSharedPreferences("pause_pocket", Context.MODE_PRIVATE)
        val name = mapOf(
            "com.google.android.apps.nbu.paisa.user" to "Google Pay",
            "com.phonepe.app" to "PhonePe", "net.one97.paytm" to "Paytm",
            "in.org.npci.upiapp" to "BHIM", "com.naviapp" to "Navi"
        )[target] ?: target
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 42, 48, 38)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(27, 29, 43), Color.rgb(15, 25, 29))).apply {
                cornerRadius = 42f; setStroke(2, Color.rgb(157, 202, 103))
            }
        }
        val title = TextView(this).apply {
            text = "🌸  Pause & Pocket  🌙"
            textSize = 23f; setTextColor(Color.rgb(246,238,220)); typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        val blossom = TextView(this).apply {
            text = "✿     ·      ✧      ·     ✿"
            textSize = 22f; setTextColor(Color.rgb(238, 165, 192)); gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(blossom)
        val question = TextView(this).apply {
            text = "Take a little pause."
            textSize = 21f; setTextColor(Color.rgb(238,165,192)); typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 24, 0, 8)
        }
        root.addView(question)
        val sub = TextView(this).apply {
            text = "Is it important for your happiness, or is it just a momentary temptation?\n\nPayment app: $name"
            textSize = 15f; setTextColor(Color.rgb(210,210,218))
        }
        root.addView(sub)
        fun styledField(hintText: String, numeric: Boolean = false) = EditText(this).apply {
            hint = hintText; textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(24, 16, 24, 16)
            background = GradientDrawable().apply { setColor(Color.rgb(39, 41, 52)); cornerRadius = 24f; setStroke(1, Color.rgb(75, 78, 91)) }
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val purchase = styledField("What are you buying? (optional)")
        root.addView(purchase)
        val amount = styledField("Amount in ₹ (optional)", true)
        root.addView(amount)
        val confirm = styledField("Type: Yeah I want this it is important").apply { setSingleLine(true) }
        root.addView(confirm)
        val ok = Button(this).apply {
            text = "Continue under the moon  →"; isAllCaps = false; setBackground(GradientDrawable().apply { setColor(Color.rgb(157,202,103)); cornerRadius = 28f }); setTextColor(Color.rgb(20,30,18))
            setOnClickListener {
                if (confirm.text.toString() != "Yeah I want this it is important") {
                    Toast.makeText(this@SpendingGateService, "Please type the exact sentence.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                dismissOverlay()
            }
        }
        root.addView(ok)
        val cancel = Button(this).apply {
            text = "Cancel · go back"; isAllCaps = false; setTextColor(Color.rgb(238,165,192))
            setOnClickListener {
                dismissOverlay()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
        root.addView(cancel)
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.58f
        }
        overlay = root
        try { wm?.addView(root, params) } catch (_: Exception) { overlay = null }
    }

    private fun dismissOverlay() {
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    override fun onInterrupt() { dismissOverlay() }
    override fun onDestroy() { dismissOverlay(); super.onDestroy() }
}
