package com.abhijit.pausepocket

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.sin

/** Original Canvas illustration inspired by the user's moonlit meadow painting. */
class NightMeadowView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    private fun fill(color: Int) {
        paint.color = color
        paint.shader = null
        paint.style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        paint.shader = android.graphics.LinearGradient(
            0f, 0f, w, h,
            Color.rgb(18, 22, 36), Color.rgb(24, 39, 35), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(0f, 0f, w, h, dp(22f), dp(22f), paint)
        paint.shader = null

        // Moon and soft halo.
        paint.shader = RadialGradient(
            w * 0.79f, h * 0.25f, dp(43f),
            intArrayOf(0x66fff1cf, 0x22fff1cf, 0x00fff1cf),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(w * 0.79f, h * 0.25f, dp(43f), paint)
        paint.shader = null
        fill(0xffffedc9.toInt())
        canvas.drawCircle(w * 0.79f, h * 0.25f, dp(22f), paint)
        fill(0xffe6d9bc.toInt())
        for (i in 0..5) {
            val fi = i.toFloat()
            canvas.drawCircle(
                w * 0.79f + sin(fi * 2f) * dp(7f),
                h * 0.25f + sin(fi * 3.1f) * dp(6f),
                dp(2f), paint
            )
        }

        // Rolling meadow.
        fill(0xff344b37.toInt())
        val hill = Path().apply {
            moveTo(0f, h * 0.78f)
            cubicTo(w * 0.22f, h * 0.62f, w * 0.56f, h * 0.82f, w, h * 0.66f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        canvas.drawPath(hill, paint)
        fill(0xff526e42.toInt())
        val hill2 = Path().apply {
            moveTo(0f, h * 0.87f)
            cubicTo(w * 0.3f, h * 0.73f, w * 0.7f, h * 0.9f, w, h * 0.79f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        canvas.drawPath(hill2, paint)

        // Cherry tree trunk and branches.
        paint.color = 0xff624532.toInt()
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = dp(8f)
        canvas.drawLine(w * 0.18f, h * 0.83f, w * 0.25f, h * 0.28f, paint)
        paint.strokeWidth = dp(4f)
        canvas.drawLine(w * 0.25f, h * 0.47f, w * 0.11f, h * 0.28f, paint)
        canvas.drawLine(w * 0.24f, h * 0.42f, w * 0.4f, h * 0.22f, paint)
        canvas.drawLine(w * 0.23f, h * 0.34f, w * 0.17f, h * 0.17f, paint)
        canvas.drawLine(w * 0.25f, h * 0.29f, w * 0.33f, h * 0.12f, paint)
        paint.style = Paint.Style.FILL

        // Blossom canopy clusters.
        val blossom = 0xffffc6d7.toInt()
        val pale = 0xffffdce5.toInt()
        val clusters = listOf(
            0.12f to 0.22f, 0.23f to 0.16f, 0.34f to 0.19f,
            0.15f to 0.34f, 0.31f to 0.31f, 0.42f to 0.28f
        )
        clusters.forEachIndexed { index, pair ->
            val cx = w * pair.first
            val cy = h * pair.second
            for (j in 0..10) {
                val dx = (((j * 17 + index * 11) % 31) - 15).toFloat() * dp(1f)
                val dy = (((j * 13 + index * 7) % 25) - 12).toFloat() * dp(1f)
                fill(if (j % 3 == 0) pale else blossom)
                canvas.drawCircle(cx + dx, cy + dy, dp(if (j % 4 == 0) 4f else 3f), paint)
            }
        }

        // A few falling petals.
        for (i in 0..15) {
            val fi = i.toFloat()
            val x = w * (0.39f + (i % 5).toFloat() * 0.075f)
            val y = h * (0.39f + (i / 5).toFloat() * 0.12f) + sin(fi) * dp(4f)
            fill(if (i % 2 == 0) pale else blossom)
            canvas.save()
            canvas.rotate((i * 19 % 50).toFloat(), x, y)
            canvas.drawOval(x - dp(2f), y - dp(4f), x + dp(2f), y + dp(4f), paint)
            canvas.restore()
        }

        // Two small silhouettes walking together.
        drawPerson(canvas, w * 0.61f, h * 0.73f, 1f, 0xff151a20.toInt())
        drawPerson(canvas, w * 0.69f, h * 0.75f, 0.82f, 0xff151a20.toInt())

        // Tiny meadow flowers.
        for (i in 0..8) {
            val x = w * (0.08f + i.toFloat() * 0.105f)
            val y = h * (0.91f + (i % 2).toFloat() * 0.025f)
            fill(0xffffd7e1.toInt())
            canvas.drawCircle(x, y, dp(2.5f), paint)
            fill(0xffffdca0.toInt())
            canvas.drawCircle(x, y, dp(1f), paint)
        }
    }

    private fun drawPerson(canvas: Canvas, x: Float, y: Float, scale: Float, color: Int) {
        fill(color)
        canvas.drawCircle(x, y - dp(18f) * scale, dp(4f) * scale, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(3f) * scale
        paint.strokeCap = Paint.Cap.ROUND
        canvas.drawLine(x, y - dp(13f) * scale, x, y, paint)
        canvas.drawLine(x, y - dp(9f) * scale, x - dp(6f) * scale, y - dp(3f) * scale, paint)
        canvas.drawLine(x, y - dp(9f) * scale, x + dp(6f) * scale, y - dp(4f) * scale, paint)
        canvas.drawLine(x, y, x - dp(5f) * scale, y + dp(9f) * scale, paint)
        canvas.drawLine(x, y, x + dp(6f) * scale, y + dp(8f) * scale, paint)
        paint.style = Paint.Style.FILL
    }
}
